#include<iostream>
using namespace std;
int timesTen(int num)
{
	
}
int main()
{
	int num;
	timesTen(num);
			




}

